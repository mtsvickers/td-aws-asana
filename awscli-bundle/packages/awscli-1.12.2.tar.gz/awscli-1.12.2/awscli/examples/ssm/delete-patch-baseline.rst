**To delete a patch baseline**

This example deletes a patch baseline.

Command::

  aws ssm delete-patch-baseline --baseline-id "pb-045f10b4f382baeda"

Output::

  {
    "BaselineId": "pb-045f10b4f382baeda"
  }
